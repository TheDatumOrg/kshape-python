# k-Shape Time-Series Clustering

This is the repository for python implementation of [k-Shape](http://www.cs.columbia.edu/~jopa/kshape.html) paper titled "k-Shape: Efficient and Accurate Clustering of Time Series" published at ACM SIGMOD 2015. The paper is available in [here](http://www.cs.columbia.edu/~jopa/Papers/PaparrizosSIGMOD2015.pdf).

<p align="center" width="100%">
    <img width="40%" src="https://github.com/johnpaparrizos/kshapetemp/blob/main/docs/kShape.png">
</p>

## Installation

### Install from [pip](https://pypi.python.org/pypi/kshape)
```
$ pip install kshape
```

### Install from source
```
$ git clone https://github.com/johnpaparrizos/kshapetem
$ cd kshapetem
$ python setup.py install
```

## Data
We present our results by evaulating k-Shape model on two sources of data: 
* The [UCR Univariate archive](http://www.timeseriesclassification.com/Downloads/Archives/Univariate2018_arff.zip), which contains the 128 univariate time series datasets. 
* The [UAE Multivariate archive](http://www.timeseriesclassification.com/Downloads/Archives/Multivariate2018_arff.zip), which contains the 28 multivariate time series datasets.

## Usage

### Univariate Example:
```python
import numpy as np
from kshape.core import kshape

univariate_ts_datasets = np.random.rand(200, 60)
num_clusters = 3
model = kshape(np.expand_dims(univariate_ts_datasets, axis=2), num_clusters, centroid_init='zero', max_iter=100)

labels = np.zeros(univariate_ts_datasets.shape[0])
for i in range(num_clusters):
    labels[model[i][1]] = i
    
cluster_centroids = np.zeros((num_clusters, univariate_ts_datasets.shape[1], univariate_ts_datasets.shape[2]))
for i in range(num_clusters):
    cluster_centroids[i] = model[i][0]
```

### Multivariate Example:
```python
import numpy as np
from kshape.core import kshape

multivariate_ts_datasets = np.random.rand(200, 60, 6)
num_clusters = 3
model = kshape(multivariate_ts_datasets, num_clusters, centroid_init='zero', max_iter=100)

labels = np.zeros(multivariate_ts_datasets.shape[0])
for i in range(num_clusters):
    labels[model[i][1]] = i
    
cluster_centroids = np.zeros((num_clusters, multivariate_ts_datasets.shape[1], multivariate_ts_datasets.shape[2]))
for i in range(num_clusters):
    cluster_centroids[i] = model[i][0]
```

## Results

The following tables contain the average Rand Index, Adjusted Rand Index, and Normalized Mutual Information over 10 runs for k-Shape model on the univariate and multivariate datasets respectively.

### Univariate Results:

| Datasets              | Rand Index | Adjusted Rand Index | Normalized Mutual Information     | 
|:-----------------------:|:------------:|:------------:|:------------:|
| ACSF1               | 0.728889447  | 0.139127178  | 0.385362576  |
| Adiac               | 0.948199219|0.237456072|0.585026777|
| AllGestureWiimoteX               | 0.830988989|0.091833105|0.19967124|
| AllGestureWiimoteY               |0.83356036|0.1306081|0.265320116|
| AllGestureWiimoteZ               |0.831796196|0.08184644|0.184288361|
| ArrowHead               |0.623696682|0.176408828|0.251716443|
| Beef               |0.666553672|0.102291622|0.274983496|
| BeetleFly               |0.518461538|0.037243262|0.049170634|
| BirdChicken               |0.522948718|0.046863444|0.055805713|
| BME               |0.623662322|0.209189215|0.337562447|
| Car               |0.668095238|0.142785926|0.222574613|
| CBF               |0.875577393|0.724563717|0.770334057|
| Chinatown               |0.526075568|0.041117166|0.015693819|
| ChlorineConcentration               |0.526233814|-0.001019087|0.000772354| 
| CinCECGTorso               |0.625307149|0.051803606|0.093350668|
| Coffee               |0.726493506|0.453837834|0.421820948|
| Computers               |0.529187976|0.058481715|0.0485609|
| CricketX               |0.869701787|0.174655947|0.357916915|
| CricketY               |0.873153945|0.206381317|0.373656368|
| CricketZ               |0.869909812|0.172669605|0.355604411|
| Crop               |0.924108349|0.241974335|0.4388123|
| DiatomSizeReduction               |0.919179195|0.807710845|0.827117298|
| DistalPhalanxOutlineAgeGroup               |0.722184825|0.435943568|0.329905608|
| DistalPhalanxOutlineCorrect               |0.499455708|-0.001030351|2.97E-05|
| DistalPhalanxTW               |0.839607976|0.59272726|0.531060255|
| DodgerLoopDay               |0.781988229|0.210916925|0.402897375|
| DodgerLoopGame               |0.570071757|0.140620499|0.117161969|
| DodgerLoopWeekend               |0.830807063|0.657966909|0.628131221|
| Earthquakes               |0.541659908|0.024267193|0.006262268|
| ECG200               |0.613753769|0.215794222|0.12870574|
| ECG5000               |0.771307998|0.530703353|0.523220504|
| ECGFiveDays               |0.811446734|0.623122565|0.586492573|
| ElectricDevices               |0.693551963|0.071161449|0.177107461|
| EOGHorizontalSignal               |0.86864851|0.227034804|0.408923026|
| EOGVerticalSignal               |0.87082521|,0.200763231,0.37416983|
| EthanolLevel               |0.622273617|0.003480205|0.007896876|
| FaceAll               |0.910295025|0.433266026|0.610598916|
| FaceFour               |0.757335907|0.374239896|0.466746543|
| FacesUCR               |0.910295025|0.433266026|0.610598916|
| FiftyWords               |0.951558207|0.358925864|0.651569015|
| Fish               |0.785345886|0.189885615|0.327951361|
| FordA               |0.564619244|0.129237686|0.096210429|
| FordB               |0.516109383|0.032218211|0.023938345|
| FreezerRegularTrain               |0.638744137|0.277488682|0.211547387|
| FreezerSmallTrain               |0.639049682|0.278099783|0.212045663|
| Fungi               |0.829126823|0.357543672|0.731173267|
| GestureMidAirD1               |0.944819412|0.2937662|0.635503444|
| GestureMidAirD2               |0.947697224|0.348582475|0.677310905|
| GestureMidAirD3               |0.931266132|0.126759199|0.458782509|
| GesturePebbleZ1               |0.883081466|0.585931482|0.675293127|
| GesturePebbleZ2               |0.881353135|0.580554538|0.66392792|
| GunPoint               |0.497487437|-0.005050505|0|
| GunPointAgeSpan               |0.531991131|0.064141145|0.053146884|
| GunPointMaleVersusFemale               |0.790127618|0.580242081|0.571776535|
| GunPointOldVersusYoung               |0.518734664|0.037473134|0.028207614|
| Ham               |0.528831556|0.057673104|0.044612673|
| HandOutlines               |0.682856686|0.360051947|0.251176285|
| Haptics               |0.689075575|0.063709939|0.09042192|
| Herring               |0.501464075|0.003160642|0.007650463|
| HouseTwenty               |0.520197437|0.040014774|0.03248788|
| InlineSkate               |0.734065189|0.039846163|0.104643365|
| InsectEPGRegularTrain               |0.706511773|0.363941816|0.379556522|
| InsectEPGSmallTrain               |0.70409136|0.361370964|0.379504988|
| InsectWingbeatSound               |0.792640539|0.196225831|0.402373638|
| ItalyPowerDemand               |0.60972886|0.219608406|0.188152403|
| LargeKitchenAppliances               |0.570070672|0.125576669|0.130422376|
| Lightning2               |0.531294766|0.057017617|0.089783145|
| Lightning7               |0.806175515|0.322963065|0.506494431|
| Mallat               |0.924756461|0.721656055|0.869891088|
| Meat               |0.761918768|0.494403401|0.580422751|
| MedicalImages               |0.672005013|0.073490231|0.2287366|
| MelbournePedestrian               |0.869441656|0.349104777|0.470402239|
| MiddlePhalanxOutlineAgeGroup               |0.729585262|0.423115226|0.401722498|
| MiddlePhalanxOutlineCorrect               |0.49977175|-0.00373634|0.000894849|
| MiddlePhalanxTW               |0.809347564|0.449636118|0.431364361|
| MixedShapesRegularTrain               |0.800991079|0.420414418|0.488448041|
| MixedShapesSmallTrain               |0.800795029|0.419036374|0.4766379|
| MoteStrain               |0.804809143|0.609589015|0.501865061|
| NonInvasiveFetalECGThorax1               |0.950981974|0.33373922|0.676420909|
| NonInvasiveFetalECGThorax2               |0.967174335|0.465761156|0.765614776|
| OliveOil               |0.806892655|0.570012361|0.607418333|
| OSULeaf               |0.785105837|0.263550973|0.361580708|
| PhalangesOutlinesCorrect               |0.505362413|0.01070369|0.010221576|
| Phoneme               |0.92769786|0.034705732|0.210108984|
| PickupGestureWiimoteZ               |0.854545455|0.288210152|0.540234358|
| PigAirwayPressure               |0.903229862|0.03338252|0.427579631|
| PigArtPressure               |0.959821502|0.273442178|0.717389411|
| PigCVP               |0.961346772|0.194516974|0.658363736|
| PLAID               |0.859444881|0.281634259|0.40487855|
| Plane               |0.911765778|0.708344209|0.851592604|
| PowerCons               |0.57637883|0.153069982|0.137929689|
| ProximalPhalanxOutlineAgeGroup               |0.752674183|0.477154395|0.468537655|
| ProximalPhalanxOutlineCorrect               |0.53390585|0.066453288|0.08535263|
| ProximalPhalanxTW               |0.831222703|0.569454692|0.550694374|
| RefrigerationDevices               |0.556208278|0.007595278|0.009437609|
| Rock               |0.696935818|0.218081493|0.322230745|
| ScreenType               |0.559603738|0.010528249|0.011742597|
| SemgHandGenderCh2               |0.546315412|0.091559428|0.058471281|
| SemgHandMovementCh2               |0.739443579|0.116429522|0.209097135|
| SemgHandSubjectCh2               |0.724787047|0.19660949|0.263889093|
| ShakeGestureWiimoteZ               |0.903171717|0.471533102|0.684959604|
| ShapeletSim               |0.699939698|0.400050425|0.377331686|
| ShapesAll               |0.978735474|0.42589872|0.742885495|
| SmallKitchenAppliances               |0.398853939|0.004907405|0.02514159|
| SmoothSubspace               |0.642434783|0.198252944|0.19954272|
| SonyAIBORobotSurface1               |0.728057763|0.455518203|0.464021606|
| SonyAIBORobotSurface2               |0.589140522|0.172496802|0.11750294|
| StarLightCurves               |0.769194065|0.520688962|0.610221341|
| Strawberry               |0.504165518|-0.019398783|0.123396507|
| SwedishLeaf               |0.890254013|0.312306779|0.556179611|
| Symbols               |0.880314418|0.619222941|0.757594317|
| SyntheticControl               |0.881984975|0.600681896|0.712533175|
| ToeSegmentation1               |0.50200682|0.004059369|0.005057191|
| ToeSegmentation2               |0.635618839|0.260242738|0.191505717|
| Trace               |0.711065327|0.455900994|0.598951999|
| TwoLeadECG               |0.538024968|0.076155916|0.059000693|
| TwoPatterns               |0.677979172|0.207830772|0.318418523|
| UMD               |0.597057728|0.130992637|0.189184137|
| UWaveGestureLibraryAll               |0.90364952|0.576024048|0.662693972|
| UWaveGestureLibraryX               |0.85435587|0.353963525|0.457132359|
| UWaveGestureLibraryY               |0.830476288|0.24845414|0.342123959|
| UWaveGestureLibraryZ               |0.849091206|0.350080637|0.46397562|
| Wafer               |0.541995609|0.026459678|0.010367784|
| Wine               |0.496478296|-0.005187919|0.001056479|
| WordSynonyms               |0.892537036|0.221578306|0.451754722|
| Worms               |0.647528127|0.028458575|0.062591393|
| WormsTwoClass               |0.503616566|0.00695446|0.009827969|
| Yoga               | 0.499909412|-0.000340663|7.76E-05|

### Multivariate Results:

| Datasets              | Rand Index | Adjusted Rand Index | Normalized Mutual Information     | 
|:-----------------------:|:------------:|:------------:|:------------:|
| ArticularyWordRecognition               |   |
| AtrialFibrillation               |   |
| BasicMotions               |   |
| CharacterTrajectories               |   |
| Cricket               |   |
| DuckDuckGeese               |   |
| ERing               |   |
| Epilepsy               |   |
| EthanolConcentration               |   |
| FaceDetection               |   |
| FingerMovements               |   |
| HandMovementDirection               |   |
| Handwriting               |   |
| Heartbeat               |   |
| InsectWingbeat               |   |
| JapaneseVowels               |   |
| LSST               |   |
| Libras               |   |
| MotorImagery               |   |
| NATOPS               |   |
| PenDigits               |   |
| PhonemeSpectra               |   |
| RacketSports               |   |
| SelfRegulationSCP1               |   |
| SelfRegulationSCP2               |   |
| SpokenArabicDigits               |   |
| StandWalkJump               |   |
| UWaveGestureLibrary               |   |



## References

```plain
Paparrizos J and Gravano L (2015).
k-Shape: Efficient and Accurate Clustering of Time Series.
In Proceedings of the 2015 ACM SIGMOD International Conference on Management of Data, series SIGMOD '15,
pp. 1855-1870. ISBN 978-1-4503-2758-9, http://doi.org/10.1145/2723372.2737793. '
```
